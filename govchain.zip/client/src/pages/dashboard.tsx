import { StatsOverview } from '@/components/dashboard/stats-overview';
import { BudgetOverview } from '@/components/dashboard/budget-overview';
import { RecentTransactions } from '@/components/dashboard/recent-transactions';
import { DocumentVerification } from '@/components/dashboard/document-verification';
import { BlockchainExplorer } from '@/components/dashboard/blockchain-explorer';
import { DigitalIdentity } from '@/components/dashboard/digital-identity';

export default function Dashboard() {
  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Government Transparency Dashboard</h2>
        <p className="text-slate-500 mt-1">Real-time tracking of government transactions and budget allocation</p>
      </div>

      {/* Stats Overview */}
      <StatsOverview />

      {/* Budget Overview & Recent Verifications */}
      <BudgetOverview />

      {/* Recent Transactions & Document Verification */}
      <div className="grid grid-cols-1 lg:grid-cols-7 gap-6 mb-6">
        <RecentTransactions />
        <DocumentVerification />
      </div>

      {/* Blockchain Explorer */}
      <BlockchainExplorer />

      {/* Digital Identity Management */}
      <DigitalIdentity />
    </div>
  );
}
