import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { Document } from '@shared/schema';
import { File, FileText, Upload, Search, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';

export default function Documents() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [documentHash, setDocumentHash] = useState('');
  
  const { data: documents, isLoading, refetch } = useQuery<Document[]>({
    queryKey: ['/api/documents', { status: activeTab === 'all' ? undefined : activeTab, search: searchTerm }],
  });
  
  const verifyDocumentMutation = useMutation({
    mutationFn: async (hash: string) => {
      const response = await apiRequest('POST', '/api/documents/verify', { hash });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Verification successful",
        description: "The document has been verified on the blockchain",
      });
      setDocumentHash('');
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Verification failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const uploadDocumentMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/documents/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const text = await response.text();
        throw new Error(text || response.statusText);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Document uploaded",
        description: "The document has been uploaded and is pending verification",
      });
      setSelectedFile(null);
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleUpload = () => {
    if (!selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    uploadDocumentMutation.mutate(formData);
  };

  const handleVerifyHash = () => {
    if (!documentHash) {
      toast({
        title: "No hash provided",
        description: "Please enter a document hash to verify",
        variant: "destructive",
      });
      return;
    }
    
    verifyDocumentMutation.mutate(documentHash);
  };

  const handleSearch = () => {
    refetch();
  };

  const getFileIcon = (fileType: string) => {
    switch (fileType.toLowerCase()) {
      case 'pdf':
        return <File className="text-red-500 h-5 w-5" />;
      case 'xlsx':
      case 'xls':
        return <FileText className="text-green-500 h-5 w-5" />;
      case 'docx':
      case 'doc':
        return <FileText className="text-blue-500 h-5 w-5" />;
      default:
        return <FileText className="text-slate-500 h-5 w-5" />;
    }
  };

  const formatDate = (dateString: Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Document Management</h2>
        <p className="text-slate-500 mt-1">Secure verification and management of government documents</p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Upload Document */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Upload Document</CardTitle>
            <CardDescription>Add a new document for blockchain verification</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-slate-300 border-dashed rounded-md">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-8 w-8 text-slate-400" />
                  <div className="flex text-sm text-slate-600">
                    <label 
                      htmlFor="file-upload" 
                      className="relative cursor-pointer rounded-md font-medium text-primary hover:text-primary-700"
                    >
                      <span>Upload a file</span>
                      <input 
                        id="file-upload" 
                        name="file-upload" 
                        type="file" 
                        className="sr-only"
                        onChange={handleFileChange}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-slate-500">
                    {selectedFile ? selectedFile.name : "PDF, PNG, JPG up to 10MB"}
                  </p>
                </div>
              </div>
              
              {selectedFile && (
                <Button 
                  className="w-full"
                  onClick={handleUpload}
                  disabled={uploadDocumentMutation.isPending}
                >
                  {uploadDocumentMutation.isPending ? (
                    <>
                      <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Uploading...
                    </>
                  ) : "Upload Document"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Verify Document */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Verify Document</CardTitle>
            <CardDescription>Verify document authenticity on the blockchain</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="document-hash">Document Hash</Label>
                <div className="flex mt-1">
                  <Input 
                    id="document-hash"
                    placeholder="Enter document hash (0x...)" 
                    className="rounded-r-none"
                    value={documentHash}
                    onChange={(e) => setDocumentHash(e.target.value)}
                  />
                  <Button 
                    className="rounded-l-none"
                    onClick={handleVerifyHash}
                    disabled={verifyDocumentMutation.isPending}
                  >
                    {verifyDocumentMutation.isPending ? (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Verifying...
                      </>
                    ) : "Verify"}
                  </Button>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-slate-500 mb-2">Document verification status:</p>
                <div className="bg-slate-50 p-4 rounded-lg">
                  {verifyDocumentMutation.isPending ? (
                    <div className="flex items-center">
                      <RefreshCw className="text-primary h-5 w-5 mr-2 animate-spin" />
                      <span>Verifying document on blockchain...</span>
                    </div>
                  ) : verifyDocumentMutation.isSuccess ? (
                    <div className="flex items-center">
                      <CheckCircle className="text-green-600 h-5 w-5 mr-2" />
                      <span>Document verified successfully!</span>
                    </div>
                  ) : verifyDocumentMutation.isError ? (
                    <div className="flex items-center">
                      <AlertCircle className="text-red-600 h-5 w-5 mr-2" />
                      <span>Verification failed: {verifyDocumentMutation.error.message}</span>
                    </div>
                  ) : (
                    <div className="flex items-center">
                      <AlertCircle className="text-slate-400 h-5 w-5 mr-2" />
                      <span>Enter a document hash to verify</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle>Document Repository</CardTitle>
            <div className="relative w-full md:w-64">
              <Input 
                type="text" 
                placeholder="Search documents..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="pr-10"
              />
              <Button 
                variant="ghost" 
                size="sm" 
                className="absolute right-0 top-0 h-full px-3" 
                onClick={handleSearch}
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <Tabs 
            defaultValue="all" 
            value={activeTab} 
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All Documents</TabsTrigger>
              <TabsTrigger value="verified">Verified</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-48">
              <p className="text-slate-500">Loading documents...</p>
            </div>
          ) : documents && documents.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Document</TableHead>
                    <TableHead>Upload Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Hash</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documents.map((document) => (
                    <TableRow key={document.id}>
                      <TableCell>
                        <div className="flex items-center">
                          {getFileIcon(document.fileType)}
                          <span className="ml-2">{document.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm text-slate-500">
                        {formatDate(document.uploadedAt)}
                      </TableCell>
                      <TableCell>
                        <Badge variant={document.status === 'verified' ? 'verified' : 'pending'}>
                          {document.status === 'verified' ? 'Verified' : 'Pending'}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono text-xs">
                        {document.hash.substring(0, 8)}...{document.hash.substring(document.hash.length - 8)}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">View</Button>
                          {document.status === 'pending' && (
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => verifyDocumentMutation.mutate(document.hash)}
                              disabled={verifyDocumentMutation.isPending}
                            >
                              Verify
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="flex justify-center items-center h-48">
              <p className="text-slate-500">No documents found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
