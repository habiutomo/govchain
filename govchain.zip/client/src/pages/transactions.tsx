import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import type { Transaction } from '@shared/schema';
import { School, Activity, Building, ShieldCheck, Users, Search } from 'lucide-react';

export default function Transactions() {
  const [page, setPage] = useState(1);
  const [department, setDepartment] = useState<string>('all');
  const [status, setStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  const { data: transactions, isLoading } = useQuery<Transaction[]>({
    queryKey: ['/api/transactions', { page, department, status, search: searchTerm }],
  });
  
  const { data: totalCount } = useQuery<number>({
    queryKey: ['/api/transactions/count', { department, status, search: searchTerm }],
  });
  
  const itemsPerPage = 10;
  const totalPages = totalCount ? Math.ceil(totalCount / itemsPerPage) : 0;

  const getDepartmentIcon = (department: string) => {
    switch (department.toLowerCase()) {
      case 'education':
        return <School className="text-primary-600" />;
      case 'healthcare':
        return <Activity className="text-secondary-600" />;
      case 'infrastructure':
        return <Building className="text-purple-600" />;
      case 'defense':
        return <ShieldCheck className="text-green-600" />;
      case 'social services':
        return <Users className="text-green-600" />;
      default:
        return <Activity className="text-slate-600" />;
    }
  };

  const getDepartmentBgColor = (department: string) => {
    switch (department.toLowerCase()) {
      case 'education':
        return 'bg-primary-100';
      case 'healthcare':
        return 'bg-secondary-100';
      case 'infrastructure':
        return 'bg-purple-100';
      case 'defense':
        return 'bg-green-100';
      case 'social services': 
        return 'bg-green-100';
      default:
        return 'bg-slate-100';
    }
  };

  const formatDate = (dateString: Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleSearch = () => {
    setPage(1); // Reset to first page on new search
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-800">Transaction Management</h2>
        <p className="text-slate-500 mt-1">Track and verify all government financial transactions</p>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Transaction Filters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="col-span-2">
              <div className="relative">
                <Input 
                  type="text" 
                  placeholder="Search transactions..." 
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="pr-10"
                />
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="absolute right-0 top-0 h-full px-3" 
                  onClick={handleSearch}
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <Select 
                value={department} 
                onValueChange={setDepartment}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="infrastructure">Infrastructure</SelectItem>
                  <SelectItem value="defense">Defense</SelectItem>
                  <SelectItem value="social services">Social Services</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Select 
                value={status} 
                onValueChange={setStatus}
              >
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="verified">Verified</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Transaction Records</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center items-center h-48">
              <p className="text-slate-500">Loading transactions...</p>
            </div>
          ) : transactions && transactions.length > 0 ? (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Department</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Transaction Hash</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="flex items-center">
                            <div className={`h-8 w-8 ${getDepartmentBgColor(transaction.department)} rounded-md flex items-center justify-center mr-3`}>
                              {getDepartmentIcon(transaction.department)}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-slate-900">{transaction.department}</div>
                              <div className="text-xs text-slate-500">{transaction.category}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{transaction.description || "N/A"}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-medium">
                            ${transaction.amount.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-slate-500">{formatDate(transaction.date)}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={transaction.status === 'verified' ? 'verified' : 'pending'}>
                            {transaction.status === 'verified' ? 'Verified' : 'Pending'}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-mono">
                            {transaction.transactionHash.substring(0, 6)}...
                            {transaction.transactionHash.substring(transaction.transactionHash.length - 4)}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            
              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-slate-500">
                    Showing {((page - 1) * itemsPerPage) + 1} to {Math.min(page * itemsPerPage, totalCount || 0)} of {totalCount} entries
                  </div>
                  <div className="flex gap-1">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setPage(p => Math.max(1, p - 1))}
                      disabled={page === 1}
                    >
                      Previous
                    </Button>
                    
                    {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                      let pageNum;
                      if (totalPages <= 5) {
                        pageNum = i + 1;
                      } else if (page <= 3) {
                        pageNum = i + 1;
                      } else if (page >= totalPages - 2) {
                        pageNum = totalPages - 4 + i;
                      } else {
                        pageNum = page - 2 + i;
                      }
                      
                      return (
                        <Button
                          key={pageNum}
                          variant={page === pageNum ? "secondary" : "outline"}
                          size="sm"
                          onClick={() => setPage(pageNum)}
                        >
                          {pageNum}
                        </Button>
                      );
                    })}
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                      disabled={page === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="flex justify-center items-center h-48">
              <p className="text-slate-500">No transactions found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
