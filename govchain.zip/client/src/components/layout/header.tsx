import { useState } from 'react';
import { Menu, Bell, User } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

interface HeaderProps {
  toggleSidebar: () => void;
}

export function Header({ toggleSidebar }: HeaderProps) {
  const [notificationsOpen, setNotificationsOpen] = useState(false);

  const notifications = [
    {
      id: 1,
      title: "Document verification successful",
      description: "National ID verification completed",
      time: "2 minutes ago",
      type: "success"
    },
    {
      id: 2,
      title: "New budget transaction recorded",
      description: "Education department allocation verified",
      time: "1 hour ago",
      type: "info"
    },
    {
      id: 3,
      title: "Pending transaction requires review",
      description: "Infrastructure project #2234 needs approval",
      time: "3 hours ago",
      type: "warning"
    }
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-40">
      <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3 lg:px-6">
        <div className="flex items-center space-x-4">
          <button 
            onClick={toggleSidebar}
            className="p-2 rounded-md text-slate-700 hover:bg-slate-100 lg:hidden"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="text-white h-5 w-5"
              >
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-slate-800">GovChain</h1>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <DropdownMenu 
            open={notificationsOpen} 
            onOpenChange={setNotificationsOpen}
          >
            <DropdownMenuTrigger asChild>
              <button className="p-2 rounded-full text-slate-700 hover:bg-slate-100 relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-0 right-0 h-5 w-5 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-medium">
                  {notifications.length}
                </span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-80" align="end">
              <DropdownMenuLabel>Notifications</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {notifications.map(notification => (
                <DropdownMenuItem key={notification.id} className="p-0">
                  <div className="px-4 py-3 hover:bg-slate-50 w-full cursor-pointer border-b border-slate-100">
                    <div className="flex items-start">
                      <div className={`h-8 w-8 rounded-full flex items-center justify-center mr-3
                        ${notification.type === 'success' ? 'bg-green-100' : 
                          notification.type === 'info' ? 'bg-blue-100' : 
                          'bg-yellow-100'}
                      `}>
                        <svg
                          xmlns="http://www.w3.org/2000/svg" 
                          viewBox="0 0 24 24" 
                          fill="none" 
                          stroke="currentColor" 
                          strokeWidth="2" 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          className={`h-4 w-4
                            ${notification.type === 'success' ? 'text-green-600' : 
                              notification.type === 'info' ? 'text-blue-600' : 
                              'text-yellow-600'}
                          `}
                        >
                          {notification.type === 'success' ? (
                            <path d="M20 6L9 17l-5-5" />
                          ) : notification.type === 'info' ? (
                            <><circle cx="12" cy="12" r="1"/><path d="M12 16v-4"/><path d="M12 8h.01"/></>
                          ) : (
                            <><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></>
                          )}
                        </svg>
                      </div>
                      <div>
                        <p className="text-sm font-medium">{notification.title}</p>
                        <p className="text-xs text-slate-500">{notification.description}</p>
                        <p className="text-xs text-slate-400 mt-1">{notification.time}</p>
                      </div>
                    </div>
                  </div>
                </DropdownMenuItem>
              ))}
              <DropdownMenuItem className="justify-center font-medium text-primary h-8">
                View all notifications
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center space-x-2">
                <Avatar>
                  <AvatarImage 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" 
                    alt="User avatar" 
                  />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <span className="hidden md:block text-sm font-medium">John Doe</span>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="text-slate-500 h-4 w-4"
                >
                  <path d="m6 9 6 6 6-6"/>
                </svg>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Your Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
