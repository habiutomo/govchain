import { Link, useLocation } from 'wouter';
import { LayoutDashboard, FileText, UserCheck, Server, RefreshCcw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SidebarProps {
  sidebarOpen: boolean;
}

export function Sidebar({ sidebarOpen }: SidebarProps) {
  const [location] = useLocation();

  const menuItems = [
    { 
      name: 'Dashboard', 
      path: '/dashboard', 
      icon: <LayoutDashboard className="text-lg mr-3 h-5 w-5" /> 
    },
    { 
      name: 'Transactions', 
      path: '/transactions', 
      icon: <RefreshCcw className="text-lg mr-3 h-5 w-5" /> 
    },
    { 
      name: 'Documents', 
      path: '/documents', 
      icon: <FileText className="text-lg mr-3 h-5 w-5" /> 
    },
    { 
      name: 'Digital Identity', 
      path: '/identity', 
      icon: <UserCheck className="text-lg mr-3 h-5 w-5" /> 
    },
    { 
      name: 'Blockchain Explorer', 
      path: '/explorer', 
      icon: <Server className="text-lg mr-3 h-5 w-5" /> 
    },
  ];

  return (
    <aside 
      className={cn(
        "w-64 bg-white shadow-md z-30 fixed inset-y-0 left-0 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}
    >
      <div className="h-full flex flex-col overflow-y-auto">
        <div className="px-4 py-6 border-b border-slate-200 hidden lg:block">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="text-white h-5 w-5"
              >
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-slate-800">GovChain</h1>
          </div>
        </div>
        
        <nav className="flex-1 px-2 pt-4 pb-4 space-y-1">
          {menuItems.map(item => (
            <Link 
              key={item.path} 
              href={item.path} 
              className={cn(
                "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === item.path 
                  ? "bg-primary-50 text-primary-700" 
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              )}
            >
              {item.icon}
              {item.name}
            </Link>
          ))}
        </nav>
        
        <div className="px-3 py-4 border-t border-slate-200">
          <div className="flex items-center space-x-3 bg-slate-50 p-3 rounded-lg">
            <div className="flex-shrink-0">
              <div className="bg-green-500 h-2 w-2 rounded-full"></div>
            </div>
            <div className="flex-1">
              <div className="text-xs font-medium text-slate-500">Network Status</div>
              <div className="text-sm font-medium">Operational</div>
            </div>
            <div className="h-7 w-7 rounded-full bg-slate-100 flex items-center justify-center">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                className="text-slate-500 h-4 w-4"
              >
                <circle cx="12" cy="12" r="1"/><path d="M12 16v-4"/><path d="M12 8h.01"/>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
